<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
  </head>
  <body>
    <form action="loginform.php" method="post">
      name:<input type="text" name="name" /> 
      std_id:<input type="text"name="std_id"/>
      address:<input type="text"name="address">
      email:<input type="text"name="email">
      <input type="submit">
      
    </form>
    
    
  </body>
</html>